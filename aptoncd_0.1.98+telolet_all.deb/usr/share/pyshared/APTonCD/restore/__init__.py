__all__ = ['restoreWindow','restoreFromDialog']

