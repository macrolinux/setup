__all__ = ['createWindow', 'burnproperties', 'finisheddialog']
